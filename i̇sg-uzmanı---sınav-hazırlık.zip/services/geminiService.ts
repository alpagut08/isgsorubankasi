import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Question, ExamClass } from "../types";

// JSON Schema for Question Generation
const questionSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    questions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          questionText: { type: Type.STRING },
          options: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "Exactly 5 options (A, B, C, D, E)"
          },
          correctIndex: { type: Type.INTEGER, description: "0-based index of correct answer" },
          explanation: { type: Type.STRING, description: "Short explanation of why the answer is correct" }
        },
        required: ["questionText", "options", "correctIndex", "explanation"]
      }
    }
  }
};

export const generateQuestions = async (topicTitle: string, examClass: ExamClass, count: number = 5): Promise<Question[]> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      console.warn("API Key not found. Returning mock questions.");
      return getMockQuestions(topicTitle);
    }

    const ai = new GoogleGenAI({ apiKey });
    
    const prompt = `
      Sen uzman bir İş Sağlığı ve Güvenliği (İSG) eğitmenisin.
      Konu: "${topicTitle}"
      Hedef Kitle: ${examClass} İş Güvenliği Uzmanlığı Sınavı adayları.
      
      Lütfen bu konuyla ilgili mevzuata dayalı, zorluk derecesi sınava uygun ${count} adet çoktan seçmeli soru hazırla.
      Her sorunun tam olarak 5 şıkkı olmalı.
      Cevaplar kesin ve yönetmeliğe/kanuna uygun olmalı.
      Çıktıyı JSON formatında ver.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: questionSchema,
        temperature: 0.4 // Lower temperature for factual accuracy
      }
    });

    const jsonText = response.text;
    if (!jsonText) throw new Error("No response from AI");

    const parsed = JSON.parse(jsonText);
    
    return parsed.questions.map((q: any, index: number) => ({
      id: `gen-${Date.now()}-${index}`,
      text: q.questionText,
      options: q.options,
      correctAnswerIndex: q.correctIndex,
      explanation: q.explanation
    }));

  } catch (error) {
    console.error("Gemini generation error:", error);
    // Fallback to mock data if API fails or key is missing
    return getMockQuestions(topicTitle);
  }
};

const getMockQuestions = (topic: string): Question[] => {
  return [
    {
      id: 'm1',
      text: `${topic} kapsamında, işveren risk değerlendirmesi yaparken aşağıdakilerden hangisini dikkate almak zorunda değildir?`,
      options: [
        'Çalışanların kişisel özelliklerini',
        'İşyerinin konumunu',
        'Kullanılan iş ekipmanlarını',
        'Çalışanların medeni durumunu',
        'Tehlikeli maddelerin yapısını'
      ],
      correctAnswerIndex: 3,
      explanation: 'Çalışanların medeni durumu risk değerlendirmesi için doğrudan bir kriter değildir.'
    },
    {
      id: 'm2',
      text: `${topic} uyarınca, acil eylem planı en geç ne kadar sürede bir yenilenmelidir (Çok Tehlikeli sınıf için)?`,
      options: [
        '1 yıl',
        '2 yıl',
        '3 yıl',
        '4 yıl',
        '6 yıl'
      ],
      correctAnswerIndex: 1,
      explanation: 'Çok tehlikeli sınıfta 2, tehlikeli sınıfta 4, az tehlikeli sınıfta 6 yılda bir yenilenir.'
    }
  ];
};