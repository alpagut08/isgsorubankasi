
import React, { useState } from 'react';
import { ExamClass, Topic, TopicType, Question, AppState } from './types';
import { TOPICS } from './constants';
import Quiz from './components/Quiz';
import { 
  BookOpen, 
  GraduationCap, 
  BrainCircuit, 
  ArrowLeft, 
  FileText,
  Trophy,
  ChevronRight
} from 'lucide-react';

import {
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

function App() {
  const [state, setState] = useState<AppState>({
    selectedClass: ExamClass.None,
    currentView: 'dashboard',
    selectedTopic: null,
    quizQuestions: []
  });
  
  const [lastScore, setLastScore] = useState<{correct: number, total: number} | null>(null);

  // Handlers
  const handleClassSelect = (cls: ExamClass) => {
    setState(prev => ({ ...prev, selectedClass: cls, currentView: 'topic-list' }));
  };

  const handleBack = () => {
    if (state.currentView === 'topic-list') {
      setState(prev => ({ ...prev, currentView: 'dashboard', selectedClass: ExamClass.None }));
    } else if (state.currentView === 'results') {
      setState(prev => ({ ...prev, currentView: 'topic-list', quizQuestions: [] }));
    } else if (state.currentView === 'quiz') {
       const confirm = window.confirm("Sınavı yarıda bırakmak istiyor musunuz?");
       if(confirm) setState(prev => ({ ...prev, currentView: 'topic-list', quizQuestions: [] }));
    }
  };

  const handleTopicSelect = (topic: Topic) => {
    setState(prev => ({ 
      ...prev, 
      selectedTopic: topic, 
      quizQuestions: topic.questions,
      currentView: 'quiz'
    }));
  };

  const handleQuizFinish = (correct: number, total: number) => {
    setLastScore({ correct, total });
    setState(prev => ({ ...prev, currentView: 'results' }));
  };

  // Renderers
  const renderDashboard = () => (
    <div className="flex flex-col items-center justify-center min-h-[80vh] p-4">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4 tracking-tight">
          İSG Uzmanlığı Sınav Hazırlık
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          A, B ve C Sınıfı sınavlarına kanun, yönetmelik ve tebliğ bazlı testlerle hazırlanın.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-5xl">
        {[ExamClass.A, ExamClass.B, ExamClass.C].map((cls) => (
          <button
            key={cls}
            onClick={() => handleClassSelect(cls)}
            className="group relative bg-white hover:bg-isg-50 p-8 rounded-2xl shadow-xl border border-gray-200 transition-all transform hover:-translate-y-2 hover:shadow-2xl flex flex-col items-center"
          >
            <div className={`p-4 rounded-full mb-6 ${
              cls === ExamClass.A ? 'bg-red-100 text-red-600' : 
              cls === ExamClass.B ? 'bg-yellow-100 text-yellow-600' : 
              'bg-blue-100 text-blue-600'
            }`}>
              <GraduationCap size={48} />
            </div>
            <h2 className="text-3xl font-bold text-gray-800 mb-2">{cls}</h2>
            <span className="text-gray-500">Sınıfı Uzmanlığı</span>
            <div className="mt-6 w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
              <div className="bg-isg-500 h-full w-0 group-hover:w-full transition-all duration-700 ease-out"></div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );

  const renderTopicList = () => (
    <div className="max-w-6xl mx-auto p-4 md:p-8">
      <div className="flex items-center mb-8">
        <button onClick={handleBack} className="mr-4 p-2 rounded-full hover:bg-gray-200 transition-colors">
          <ArrowLeft size={24} />
        </button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{state.selectedClass} - Konu Seçimi</h1>
          <p className="text-gray-500">Test çözmek istediğiniz kanun veya yönetmeliği seçin.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Laws */}
        <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <BookOpen size={20} className="text-indigo-600" />
            Kanunlar ve Uluslararası Sözleşmeler
          </h3>
          <div className="space-y-3">
            {TOPICS.filter(t => t.type === TopicType.KANUN).map(topic => (
              <TopicCard key={topic.id} topic={topic} onSelect={handleTopicSelect} />
            ))}
          </div>
        </div>

        {/* Regulations */}
        <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <FileText size={20} className="text-emerald-600" />
            Yönetmelikler ve Tebliğler
          </h3>
          <div className="space-y-3">
            {TOPICS.filter(t => t.type !== TopicType.KANUN).map(topic => (
              <TopicCard key={topic.id} topic={topic} onSelect={handleTopicSelect} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderResults = () => {
    if (!lastScore) return null;
    
    const percentage = lastScore.total > 0 ? Math.round((lastScore.correct / lastScore.total) * 100) : 0;
    const data = [
      { name: 'Doğru', value: lastScore.correct, color: '#10b981' },
      { name: 'Yanlış', value: lastScore.total - lastScore.correct, color: '#ef4444' },
    ];

    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] p-4">
        <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-2xl text-center">
           <div className="mb-6 flex justify-center">
             {percentage >= 70 ? (
               <div className="p-4 bg-green-100 text-green-600 rounded-full">
                 <Trophy size={64} />
               </div>
             ) : (
               <div className="p-4 bg-yellow-100 text-yellow-600 rounded-full">
                 <BrainCircuit size={64} />
               </div>
             )}
           </div>
           
           <h2 className="text-3xl font-bold text-gray-800 mb-2">
             {percentage >= 70 ? 'Harika İş!' : 'Çalışmaya Devam Etmelisin'}
           </h2>
           <p className="text-gray-500 mb-8">
             {state.selectedTopic?.title} konusunda performansın.
           </p>

           <div className="h-64 w-full mb-8">
             <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data}
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {data.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
             </ResponsiveContainer>
             <div className="flex justify-center gap-8 mt-[-130px]">
                <div className="text-center">
                  <span className="block text-3xl font-bold text-gray-800">{percentage}%</span>
                  <span className="text-xs text-gray-500">BAŞARI</span>
                </div>
             </div>
             <div className="mt-[80px] flex justify-center gap-6 text-sm">
                <div className="flex items-center gap-2"><div className="w-3 h-3 bg-green-500 rounded-full"></div> Doğru ({lastScore.correct})</div>
                <div className="flex items-center gap-2"><div className="w-3 h-3 bg-red-500 rounded-full"></div> Yanlış ({lastScore.total - lastScore.correct})</div>
             </div>
           </div>

           <button 
            onClick={handleBack}
            className="px-8 py-3 bg-isg-600 text-white rounded-lg hover:bg-isg-700 font-bold transition-colors w-full"
           >
             Konu Listesine Dön
           </button>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Navbar */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div 
            className="flex items-center cursor-pointer" 
            onClick={() => setState(prev => ({...prev, currentView: 'dashboard', selectedClass: ExamClass.None}))}
          >
             <div className="w-8 h-8 bg-gradient-to-br from-isg-400 to-isg-600 rounded-lg flex items-center justify-center text-white font-bold mr-3">
               İSG
             </div>
             <span className="font-bold text-xl text-gray-800">SınavMatik</span>
          </div>
          
          <div className="flex items-center space-x-4">
            {state.currentView !== 'dashboard' && state.selectedClass !== ExamClass.None && (
              <div className="hidden md:flex items-center text-sm text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                {state.selectedClass} Uzmanlığı
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-grow relative">
        {state.currentView === 'dashboard' && renderDashboard()}
        {state.currentView === 'topic-list' && renderTopicList()}
        {state.currentView === 'quiz' && state.selectedTopic && (
          <div className="p-4 md:p-8">
             <Quiz 
               title={state.selectedTopic.title} 
               questions={state.quizQuestions}
               onFinish={handleQuizFinish}
               onExit={handleBack}
             />
          </div>
        )}
        {state.currentView === 'results' && renderResults()}
      </main>
    </div>
  );
}

// Helper Components
const TopicCard: React.FC<{ topic: Topic, onSelect: (t: Topic) => void }> = ({ topic, onSelect }) => (
  <button
    onClick={() => onSelect(topic)}
    className="w-full text-left p-4 bg-white rounded-xl shadow-sm border border-gray-200 hover:border-isg-400 hover:shadow-md transition-all group flex items-center justify-between"
  >
    <div className="flex-1 pr-4">
      <h4 className="font-semibold text-gray-800 group-hover:text-isg-700 transition-colors leading-snug">{topic.title}</h4>
      <div className="flex items-center gap-3 mt-1.5">
        <span className="text-xs font-medium text-gray-500 bg-gray-100 px-2 py-0.5 rounded uppercase tracking-wider">{topic.type}</span>
        <span className="text-xs text-gray-400">{topic.questions.length > 0 ? `${topic.questions.length} Soru` : 'Henüz soru yok'}</span>
      </div>
    </div>
    <div className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center group-hover:bg-isg-100 transition-colors flex-shrink-0">
      <ChevronRight size={16} className="text-gray-400 group-hover:text-isg-600" />
    </div>
  </button>
);

export default App;
