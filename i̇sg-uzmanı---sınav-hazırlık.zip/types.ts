
export enum ExamClass {
  A = 'A Sınıfı',
  B = 'B Sınıfı',
  C = 'C Sınıfı',
  None = ''
}

export enum TopicType {
  KANUN = 'Kanun',
  YONETMELIK = 'Yönetmelik',
  TEBLIG = 'Tebliğ'
}

export interface Question {
  id: string;
  text: string;
  options: string[]; // Should contain 5 options
  correctAnswerIndex: number; // 0-4
  explanation?: string;
}

export interface Topic {
  id: string;
  title: string;
  type: TopicType;
  questionCount: number;
  questions: Question[];
}

export interface QuizState {
  currentQuestionIndex: number;
  score: number;
  answers: number[]; // Stores selected index for each question
  isFinished: boolean;
}

export interface AppState {
  selectedClass: ExamClass;
  currentView: 'dashboard' | 'topic-list' | 'quiz' | 'results';
  selectedTopic: Topic | null;
  quizQuestions: Question[];
}
