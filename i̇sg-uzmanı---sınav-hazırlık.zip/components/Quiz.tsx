import React, { useState } from 'react';
import { Question } from '../types';
import { CheckCircle, XCircle, AlertCircle, ChevronRight } from 'lucide-react';

interface QuizProps {
  title: string;
  questions: Question[];
  onFinish: (score: number, total: number) => void;
  onExit: () => void;
}

const Quiz: React.FC<QuizProps> = ({ title, questions, onFinish, onExit }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);

  const currentQuestion = questions[currentIndex];
  const isLastQuestion = currentIndex === questions.length - 1;

  const handleOptionSelect = (index: number) => {
    if (showExplanation) return; // Prevent changing answer after reveal
    setSelectedOption(index);
  };

  const handleConfirm = () => {
    if (selectedOption === null) return;

    const isCorrect = selectedOption === currentQuestion.correctAnswerIndex;
    if (isCorrect) setScore(s => s + 1);
    
    setShowExplanation(true);
    setAnswers([...answers, selectedOption]);
  };

  const handleNext = () => {
    if (isLastQuestion) {
      // Score is already updated in handleConfirm
      onFinish(score, questions.length); 
    } else {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setShowExplanation(false);
    }
  };

  if (questions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 bg-white rounded-lg shadow p-8 text-center">
        <AlertCircle size={48} className="text-yellow-500 mb-4" />
        <p className="text-gray-600 text-lg mb-4">Bu başlık altında henüz soru bulunmamaktadır.</p>
        <button onClick={onExit} className="px-4 py-2 bg-isg-600 text-white rounded hover:bg-isg-700">
          Geri Dön
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="bg-white rounded-t-xl p-6 border-b border-gray-200 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-gray-800">{title}</h2>
          <span className="text-sm text-gray-500">Soru {currentIndex + 1} / {questions.length}</span>
        </div>
        <button onClick={onExit} className="text-gray-500 hover:text-gray-700 text-sm">
          Çıkış
        </button>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-gray-200 h-2">
        <div 
          className="bg-isg-500 h-2 transition-all duration-300"
          style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
        ></div>
      </div>

      {/* Question Body */}
      <div className="bg-white p-6 md:p-8 shadow-lg rounded-b-xl min-h-[400px] flex flex-col">
        <div className="mb-6">
          <p className="text-lg font-medium text-gray-900 leading-relaxed">
            <span className="font-bold text-isg-600 mr-2">{currentIndex + 1}.</span>
            {currentQuestion.text}
          </p>
        </div>

        <div className="space-y-3 flex-grow">
          {currentQuestion.options.map((option, idx) => {
            let optionClass = "w-full text-left p-4 rounded-lg border-2 transition-all flex items-start gap-3 ";
            const label = String.fromCharCode(65 + idx); // A, B, C, D, E

            if (showExplanation) {
              if (idx === currentQuestion.correctAnswerIndex) {
                optionClass += "border-green-500 bg-green-50 text-green-900"; // Correct
              } else if (idx === selectedOption) {
                optionClass += "border-red-500 bg-red-50 text-red-900"; // Wrongly selected
              } else {
                optionClass += "border-gray-200 text-gray-500 opacity-60"; // Unselected
              }
            } else {
              if (idx === selectedOption) {
                optionClass += "border-isg-500 bg-isg-50 text-isg-900 shadow-sm";
              } else {
                optionClass += "border-gray-200 hover:border-isg-300 hover:bg-gray-50 text-gray-700";
              }
            }

            return (
              <button 
                key={idx}
                onClick={() => handleOptionSelect(idx)}
                disabled={showExplanation}
                className={optionClass}
              >
                <span className="font-bold min-w-[24px]">{label})</span>
                <span>{option}</span>
                {showExplanation && idx === currentQuestion.correctAnswerIndex && (
                   <CheckCircle size={20} className="ml-auto text-green-600" />
                )}
                {showExplanation && idx === selectedOption && idx !== currentQuestion.correctAnswerIndex && (
                   <XCircle size={20} className="ml-auto text-red-600" />
                )}
              </button>
            );
          })}
        </div>

        {/* Action Area */}
        <div className="mt-8 border-t pt-6">
          {!showExplanation ? (
            <div className="flex justify-end">
              <button
                onClick={handleConfirm}
                disabled={selectedOption === null}
                className={`px-8 py-3 rounded-lg font-bold text-white shadow-md transition-colors
                  ${selectedOption === null ? 'bg-gray-300 cursor-not-allowed' : 'bg-isg-600 hover:bg-isg-700'}
                `}
              >
                Cevabı Kontrol Et
              </button>
            </div>
          ) : (
            <div>
               {currentQuestion.explanation && (
                 <div className="mb-6 p-4 bg-blue-50 border-l-4 border-blue-500 rounded-r text-blue-900 text-sm">
                   <p className="font-bold mb-1 flex items-center gap-2">
                     <AlertCircle size={16}/> Açıklama:
                   </p>
                   {currentQuestion.explanation}
                 </div>
               )}
               <div className="flex justify-end">
                 <button
                   onClick={handleNext}
                   className="px-8 py-3 rounded-lg font-bold text-white shadow-md bg-gray-800 hover:bg-black flex items-center gap-2"
                 >
                   {isLastQuestion ? 'Sınavı Bitir' : 'Sonraki Soru'}
                   <ChevronRight size={18} />
                 </button>
               </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Quiz;